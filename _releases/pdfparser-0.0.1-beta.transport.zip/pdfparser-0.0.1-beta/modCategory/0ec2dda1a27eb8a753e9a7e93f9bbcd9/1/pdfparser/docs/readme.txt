#PDFparser

A MODX plugin that allows PDFs to be searched. Just save a static resource with a PDF!

The plugin automatically changes the Content Type to application/pdf and sets the template to 0.  It then extracts the text of the PDF and sets it in the introtext field, so that SimpleSearch can find it!

If you have a lot of PDFs you can use this in combinations with Collections to create a PDF Collections area. The advantage of using PDFs in Static Resources is you can update them without breaking links.